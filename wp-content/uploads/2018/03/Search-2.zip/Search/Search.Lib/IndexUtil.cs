using Lucene.Net.Analysis;
using Lucene.Net.Analysis.Standard;
using Lucene.Net.Documents;
using Lucene.Net.Index;
using Lucene.Net.Store;
using Lucene.Net.Util;
using System;
using System.Data.OleDb;
using System.IO;
using System.Text.RegularExpressions;
using System.Linq;
using PanGu;
using Lucene.Net.Analysis.PanGu;


namespace Search.Lib
{
    public class IndexUtil
    {
        private int intMergeFactor = ConfigUtil.MergeFactor;

        private int intMaxBufferedDoc = ConfigUtil.MaxBufferedDoc;

        private int intMaxFieldLength = ConfigUtil.MaxFieldLength;

        private string path = AppDomain.CurrentDomain.BaseDirectory + "INDEX";

        Analyzer analyzer = new PanGuAnalyzer();
        public void Create()
        {

            try
            {
                if (!System.IO.Directory.Exists(path))
                {
                    System.IO.Directory.CreateDirectory(path);
                }
                var files = System.IO.Directory.GetFiles(path);
                if (files.ToList().Exists(f => f.Contains("segments")))
                {
                    return;
                }
                Lucene.Net.Store.Directory directory = FSDirectory.Open(new System.IO.DirectoryInfo(path));
                //Analyzer analyzer = new StandardAnalyzer(Lucene.Net.Util.Version.LUCENE_29);
                IndexWriter writer = new IndexWriter(directory, analyzer, true, new IndexWriter.MaxFieldLength(this.intMaxFieldLength));
                writer.SetMergeFactor(this.intMergeFactor);
                writer.SetMaxBufferedDocs(this.intMaxBufferedDoc);
                writer.SetMaxFieldLength(this.intMaxFieldLength);
                writer.Optimize();
                writer.Close();
                directory.Close();
            }
            catch (System.IO.IOException e)
            {
                LogUtil.Info(e.Message);
                throw new System.Exception(e.ToString());
            }
        }

        public void Optimize(string path)
        {
            try
            {
                Lucene.Net.Store.Directory directory = FSDirectory.Open(new System.IO.DirectoryInfo(path));
                //Analyzer analyzer = new StandardAnalyzer(Lucene.Net.Util.Version.LUCENE_29);
                IndexWriter writer = new IndexWriter(directory, analyzer, false, new IndexWriter.MaxFieldLength(this.intMaxFieldLength));
                writer.SetMergeFactor(this.intMergeFactor);
                writer.SetMaxBufferedDocs(this.intMaxBufferedDoc);
                writer.SetMaxFieldLength(this.intMaxFieldLength);
                writer.SetUseCompoundFile(true);
                writer.Optimize();
                writer.Close();
                directory.Close();
            }
            catch (System.IO.IOException e)
            {
                LogUtil.Info(e.Message);
                throw new System.Exception(e.ToString());
            }
        }

        public void Cat()
        {
            Lucene.Net.Store.Directory directory = FSDirectory.Open(new System.IO.DirectoryInfo("E:\\cms\\totsearch\\tot"));
            Lucene.Net.Store.Directory directory2 = FSDirectory.Open(new System.IO.DirectoryInfo("E:\\cms\\totsearch\\bak"));
            //Analyzer analyzer = new StandardAnalyzer(Lucene.Net.Util.Version.LUCENE_29);
            IndexWriter writer = new IndexWriter(directory, analyzer, false, new IndexWriter.MaxFieldLength(this.intMaxFieldLength));
            writer.SetMergeFactor(this.intMergeFactor);
            writer.SetMaxBufferedDocs(this.intMaxBufferedDoc);
            writer.SetMaxFieldLength(this.intMaxFieldLength);
            writer.AddIndexesNoOptimize(new Lucene.Net.Store.Directory[]
			{
				directory2
			});
            LogUtil.Info(writer.NumDocs().ToString());
            writer.Optimize();
            writer.Close();
            directory.Close();
            directory2.Close();
        }

        public string RebuildIndex(string path, bool rewrite, string connstr, string table, string id, string title, string categoryid, string photo, string summary, string content, string moddate, string linkurl)
        {
            string ret = "";
            string furl = linkurl;
            if (rewrite)
            {
                this.Create();
            }
            OleDbConnection sql = null;
            sql = new OleDbConnection(connstr);
            string directory = "select * ";
            directory = directory + " from " + table;
            try
            {
                Lucene.Net.Store.Directory Directory = FSDirectory.Open(new System.IO.DirectoryInfo(path));
                //Analyzer analyzer = new StandardAnalyzer(Lucene.Net.Util.Version.LUCENE_29);
                IndexWriter cmd = new IndexWriter(Directory, analyzer, false, new IndexWriter.MaxFieldLength(this.intMaxFieldLength));
                cmd.SetMergeFactor(this.intMergeFactor);
                cmd.SetMaxBufferedDocs(this.intMaxBufferedDoc);
                cmd.SetMaxFieldLength(this.intMaxFieldLength);
                sql.Open();
                OleDbCommand dataReader = new OleDbCommand(directory, sql);
                OleDbDataReader d = dataReader.ExecuteReader();
                while (d.Read())
                {
                    DataFieldInfo s = new DataFieldInfo();
                    s.Id = d[id].ToString();
                    if (!string.IsNullOrEmpty(title))
                    {
                        s.Title = d[title].ToString();
                    }
                    if (!string.IsNullOrEmpty(categoryid))
                    {
                        s.CategoryId = d[categoryid].ToString();
                    }
                    if (!string.IsNullOrEmpty(photo))
                    {
                        s.Photo = d[photo].ToString();
                    }
                    if (!string.IsNullOrEmpty(summary))
                    {
                        s.Summary = d[summary].ToString();
                    }
                    if (!string.IsNullOrEmpty(content))
                    {
                        s.Content = d[content].ToString();
                    }
                    if (!string.IsNullOrEmpty(moddate))
                    {
                        s.ModDate = d[moddate].ToString();
                    }
                    if (!string.IsNullOrEmpty(linkurl))
                    {
                        Regex r = new Regex("\\$(.*?)\\$", RegexOptions.IgnoreCase);
                        Match i = r.Match(linkurl);
                        while (i.Success)
                        {
                            string filednm = i.Groups[1].ToString();
                            furl = linkurl.Replace("$" + filednm + "$", d[filednm].ToString());
                            i = i.NextMatch();
                        }
                    }
                    s.LinkUrl = furl;
                    this.DoIndex(cmd, s);
                }
                cmd.Optimize();
                cmd.Close();
                Directory.Close();
                ret = "success";
            }
            catch (System.Exception er)
            {
                ret = er.ToString();
            }
            finally
            {
                sql.Close();
            }
            return ret;
        }

        public void DoIndex(IndexWriter writer, DataFieldInfo df)
        {
            if (df != null)
            {
                Document doc = new Document();
                string suma = df.Summary;
                if (suma != null)
                {
                    suma = StringUtil.RemoveHtml(suma);
                    if (suma.Length > 120)
                    {
                        suma = suma.Substring(0, 120) + "...";
                    }
                    suma = suma.Replace('\'', ' ');
                    suma = suma.Replace('\n', ' ');
                    suma = suma.Replace('\r', ' ');
                }
                System.DateTime dt = DateUtil.GetDate(df.ModDate);
                doc.Add(new Field("tbname", df.TableName.ToStringOrEmpty(), Field.Store.YES, Field.Index.NOT_ANALYZED));
                doc.Add(new Field("keyname", df.KeyName.ToStringOrEmpty(), Field.Store.YES, Field.Index.NOT_ANALYZED));
                doc.Add(new Field("id", df.Id.ToStringOrEmpty(), Field.Store.YES, Field.Index.NOT_ANALYZED));
                doc.Add(new Field("Title", df.Title, Field.Store.YES, Field.Index.ANALYZED));
                doc.Add(new Field("CategoryId", df.CategoryId.ToStringOrEmpty(), Field.Store.YES, Field.Index.NOT_ANALYZED));
                doc.Add(new Field("LinkUrl", df.LinkUrl.ToStringOrEmpty(), Field.Store.YES, Field.Index.NOT_ANALYZED));
                doc.Add(new Field("Summary", suma.ToStringOrEmpty(), Field.Store.YES, Field.Index.NOT_ANALYZED));
                doc.Add(new Field("Photo", df.Photo.ToStringOrEmpty(), Field.Store.YES, Field.Index.NOT_ANALYZED));
                doc.Add(new Field("Content", df.Content.ToStringOrEmpty(), Field.Store.NO, Field.Index.ANALYZED));
                doc.Add(new Field("ModDate", DateTools.DateToString(dt, DateTools.Resolution.MILLISECOND), Field.Store.YES, Field.Index.NOT_ANALYZED));
                try
                {
                    writer.AddDocument(doc);
                }
                catch (System.Exception e)
                {
                    LogUtil.Info(e.Message);
                }
            }
        }

        public void AddIndex(DataFieldInfo df)
        {

            this.Create();

            if (df != null)
            {
                Lucene.Net.Store.Directory directory = null;
                IndexWriter writer = null;
                try
                {
                    directory = FSDirectory.Open(new System.IO.DirectoryInfo(path));
                    //Analyzer analyzer = new StandardAnalyzer(Lucene.Net.Util.Version.LUCENE_29);
                    writer = new IndexWriter(directory, analyzer, false, new IndexWriter.MaxFieldLength(this.intMaxFieldLength));
                    writer.SetMergeFactor(this.intMergeFactor);
                    writer.SetMaxBufferedDocs(this.intMaxBufferedDoc);
                    writer.SetMaxFieldLength(this.intMaxFieldLength);
                    this.DoIndex(writer, df);
                }
                catch (System.IO.IOException e)
                {
                    LogUtil.Info(e.Message);
                }
                finally
                {
                    writer.SetUseCompoundFile(true);
                    writer.Close();
                    directory.Close();
                }
            }
        }

        public void DeleteIndex(string path, string id)
        {
            try
            {
                Lucene.Net.Store.Directory directory = FSDirectory.Open(new System.IO.DirectoryInfo(path));
                IndexReader reader = IndexReader.Open(directory, false);
                Term t = new Term("id", id);
                reader.DeleteDocuments(t);
                reader.Close();
                directory.Close();
            }
            catch (System.Exception e)
            {
                LogUtil.Info(e.Message);
            }
        }
    }
}
