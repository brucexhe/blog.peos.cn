using Lucene.Net.Analysis;
using Lucene.Net.Analysis.PanGu;
using Lucene.Net.Analysis.Standard;
using Lucene.Net.Documents;
using Lucene.Net.Index;
using Lucene.Net.QueryParsers;
using Lucene.Net.Search;
using Lucene.Net.Store;
using Lucene.Net.Util;
using System;
using System.Collections.Generic;
using System.IO;

namespace Search.Lib
{
    public class SearchUtil
    {
        private static int results = 0;

        private static int totalnum = 0;

        private int cache_page = 5;



        Analyzer analyzer = new PanGuAnalyzer();

        private string path = AppDomain.CurrentDomain.BaseDirectory + "INDEX";


        public System.Collections.Generic.List<DataFieldInfo> Search(string text, int cpage, int rows)
        {
            return this.Search("", text, 0, cpage, rows, 1, -3650, 3);
        }

        public string SearchDomain()
        {
            return "search.tot.name";
        }

        public System.Collections.Generic.List<DataFieldInfo> Search(string tbname, string text, int categoryid, int cpage, int rows, int sortby, int days, int searchby)
        {
            if (cpage == 0)
            {
                cpage = 1;
            }
            if (rows == 0)
            {
                rows = 10;
            }
            string[] keys = text.Split(new char[]
			{
				' '
			});
            System.Collections.Generic.List<DataFieldInfo> list = new System.Collections.Generic.List<DataFieldInfo>();
            Lucene.Net.Store.Directory directory = FSDirectory.Open(new System.IO.DirectoryInfo(path));
            //Analyzer analyzer = new StandardAnalyzer(Lucene.Net.Util.Version.LUCENE_29);
            IndexSearcher searcher = new IndexSearcher(directory, true);
            QueryParser topicparser = new QueryParser(Lucene.Net.Util.Version.LUCENE_29, "Title", analyzer);
            topicparser.SetDefaultOperator(QueryParser.AND_OPERATOR);
            QueryParser contentparser = new QueryParser(Lucene.Net.Util.Version.LUCENE_29, "Content", analyzer);
            contentparser.SetDefaultOperator(QueryParser.AND_OPERATOR);
            Query topicquery = topicparser.Parse(text);
            Query contentquery = contentparser.Parse(text);
            BooleanQuery TopicContentQuery = new BooleanQuery();
            if (searchby == 1 || searchby == 3)
            {
                TopicContentQuery.Add(topicquery, BooleanClause.Occur.SHOULD);
            }
            if (searchby == 2 || searchby == 3)
            {
                TopicContentQuery.Add(contentquery, BooleanClause.Occur.SHOULD);
            }
            if (searchby == 0)
            {
                TopicContentQuery.Add(topicquery, BooleanClause.Occur.MUST);
            }
            BooleanQuery query = new BooleanQuery();
            query.Add(TopicContentQuery, BooleanClause.Occur.MUST);
            if (!string.IsNullOrEmpty(tbname))
            {
                Term tbTerm = new Term("tbname", tbname);
                Query tbQuery = new TermQuery(tbTerm);
                query.Add(tbQuery, BooleanClause.Occur.MUST);
            }
            if (categoryid > 0)
            {
                Term categoryTerm = new Term("CategoryId", categoryid.ToString());
                Query categoryQuery = new TermQuery(categoryTerm);
                query.Add(categoryQuery, BooleanClause.Occur.MUST);
            }
            int offset = (cpage - 1) * rows;
            System.DateTime now = System.DateTime.Now;
            System.DateTime start = System.DateTime.Now.AddDays((double)days);
            SortField sortfield;
            if (sortby == 1)
            {
                sortfield = new SortField("id", 4, true);
            }
            else
            {
                sortfield = new SortField("id", 4, false);
            }
            Sort sort = new Sort();
            sort.SetSort(sortfield);
            TermRangeFilter df = new TermRangeFilter("ModDate", DateTools.DateToString(start, DateTools.Resolution.MILLISECOND), DateTools.DateToString(now, DateTools.Resolution.MILLISECOND), true, true);
            if (cpage > this.cache_page)
            {
                this.cache_page = cpage;
            }
            TopFieldDocs docs = null;
            try
            {
                docs = searcher.Search(query, df, this.cache_page * rows, sort);
            }
            catch (System.Exception e)
            {
                LogUtil.Info(e.Message);
            }
            ScoreDoc[] scoreDocs = docs.scoreDocs;
            SearchUtil.results = scoreDocs.Length;
            SearchUtil.totalnum = docs.totalHits;
            int endof = offset + rows;
            if (endof > SearchUtil.results)
            {
                endof = SearchUtil.results;
            }
            if (offset < 0)
            {
                offset = 0;
            }
            for (int i = offset; i < endof; i++)
            {
                FieldDoc fieldDoc = (FieldDoc)scoreDocs[i];
                DataFieldInfo df2 = new DataFieldInfo();
                Document doc = searcher.Doc(scoreDocs[i].doc);
                df2.Id = doc.Get("id");
                string title = doc.Get("Title");
                string[] array = keys;
                for (int j = 0; j < array.Length; j++)
                {
                    string s = array[j];
                    title = StringUtil.Replace(title, s, "<span style=\"color:red;\">" + s + "</span>");
                }
                df2.Title = title;
                df2.CategoryId = doc.Get("CategoryId");
                df2.LinkUrl = doc.Get("LinkUrl");
                string summary = StringUtil.HtmlSafe(doc.Get("Summary"));
                array = keys;
                for (int j = 0; j < array.Length; j++)
                {
                    string s = array[j];
                    summary = StringUtil.Replace(summary, s, "<span style=\"color:red;\">" + s + "</span>");
                }
                df2.Summary = summary;
                df2.ModDate = DateTools.StringToDate(doc.Get("ModDate")).ToShortDateString();
                df2.Photo = doc.Get("Photo");
                list.Add(df2);
            }
            searcher.Close();
            directory.Close();
            return list;
        }

        public int TotalNum()
        {
            return SearchUtil.totalnum;
        }

        public int ResultNum()
        {
            return SearchUtil.results;
        }
    }
}
