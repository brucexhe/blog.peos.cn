﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MyTranslation
{
    [System.Runtime.InteropServices.ComVisibleAttribute(true)]
    public partial class FrmTranslation : Form
    {
        public int Status { get; set; }//0-none,1=doing,2=succes,3=fail
        public bool Cancel { get; set; }
        private BackgroundWorker bw = new BackgroundWorker();

        private string Result { get; set; }


        public FrmTranslation()
        {
            InitializeComponent();
        }

        private void FrmTranslation_Load(object sender, EventArgs e)
        {
            this.txtWord.Focus();
            this.txtWord.Select();
        }

        void bw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.txtResult.Text = Result;
        }

        void bw_DoWork(object sender, DoWorkEventArgs e)
        {
            var word = this.txtWord.Text.Trim();

            System.Threading.Thread.Sleep(1000);

            if (this.txtWord.Text.Trim() != word)
            {
                return;
            }

            Result = IcibaAPI.Translate(this.txtWord.Text.Trim());
        }

        private void txtWork_Click(object sender, EventArgs e)
        {
            this.txtWord.SelectAll();


        }
        private void txtWork_TextChanged(object sender, EventArgs e)
        {
            Result = "";
            var word = this.txtWord.Text.Trim();
            if (string.IsNullOrWhiteSpace(word))
            {
                this.txtResult.Text = "";
                return;
            }
            bw = new BackgroundWorker();
            bw.DoWork += bw_DoWork;
            bw.RunWorkerCompleted += bw_RunWorkerCompleted;
            bw.RunWorkerAsync();

        }


        internal void FocusInput()
        {
            this.txtWord.Focus();
            //this.txtWord.Select();
        }
    }
}
