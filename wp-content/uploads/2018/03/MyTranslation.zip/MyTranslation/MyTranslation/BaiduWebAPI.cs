﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyTranslation
{
   public  class BaiduWebAPI
    {
       public void test()
       {

            
       }
    }
}
