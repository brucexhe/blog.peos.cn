﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyTranslation.Model
{
    public class Dict
    {
        public string word { get; set; }
        public string time { get; set; }

        public string means { get; set; }

        public string en { get; set; }

        public string am { get; set; }
    }
}
