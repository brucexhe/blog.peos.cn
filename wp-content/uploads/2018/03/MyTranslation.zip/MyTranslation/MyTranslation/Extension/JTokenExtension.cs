﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyTranslation
{
    public static class JTokenExtension
    {
        public static string ToStringOrEmpty(this JToken token)
        {
            if (token == null)
            {
                return string.Empty;
            }
            return token.ToString();
        }
    }
}
