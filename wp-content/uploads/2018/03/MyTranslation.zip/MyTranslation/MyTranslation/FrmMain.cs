﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MyTranslation
{
    public partial class FrmMain : Form
    {
        HotKeys h = new HotKeys();

        private bool Exists = false;

        Dictionary<String, Form> FormList = new Dictionary<String, Form>();

        Form currentForm = null;
        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            btnTranslate_Click(btnTranslate, e);

            //这里注册了Ctrl+Alt+E 快捷键
            h.Regist(this.Handle, (int)HotKeys.HotkeyModifiers.Shift, Keys.F, CallBack);

        }
        protected override void WndProc(ref Message m)
        {
            //窗口消息处理函数
            h.ProcessHotKey(m);
            base.WndProc(ref m);
        }

        //按下快捷键时被调用的方法
        public void CallBack()
        {
            this.Show();
            HotKeys.SetForegroundWindow(this.Handle);
            this.WindowState = FormWindowState.Normal;
        }

        private void btnTranslate_Click(object sender, EventArgs e)
        {
            var frm = new FrmTranslation();
            showForm(frm, (Button)sender);

            (currentForm as FrmTranslation).FocusInput();
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            showForm(new FrmHistory(), (Button)sender);
            (currentForm as FrmHistory).reload();
        }



        private void showForm(Form form, Button btn)
        {

            if (currentForm != null && currentForm.Name == form.Text)
            {
                return;
            }

            btnTranslate.BackColor = btnHistory.BackColor = btnWorkBook.BackColor = SystemColors.Control;

            btn.BackColor = SystemColors.ButtonHighlight;

            this.panelContainer.Controls.Clear();

            if (FormList.ContainsKey(form.Text))
            {
                currentForm = FormList[form.Text];
            }
            else
            {
                currentForm = form;
                FormList.Add(form.Text, currentForm);
            }

            currentForm.TopLevel = false;
            currentForm.Dock = DockStyle.Fill;
            currentForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.panelContainer.Controls.Add(currentForm);
            currentForm.Show();
            currentForm.Activate();

        }

        private void btnWorkBook_Click(object sender, EventArgs e)
        {
            showForm(new FromWordBook(), (Button)sender);
        }

        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!Exists)
            {
                e.Cancel = true;
                this.Hide();
            }
            else
            {
                Environment.Exit(0);
            }
        }

        private void notifyIcon1_Click(object sender, EventArgs e)
        {
            this.Show();
        }

        private void 退出XToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exists = true;

            Environment.Exit(0);
        }
    }
}
