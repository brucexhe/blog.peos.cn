﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace MyTranslation
{
    public class BaiduAPI
    {

        private static string APIURL = "http://api.fanyi.baidu.com/api/trans/vip/translate?q={0}&from={1}&to={2}&appid={3}&salt={4}&sign={5}";

        private static string appid = "20180315000135793";

        private static string token = "wFzpXfDXUmu4fLmM1TEU";

        private static string salt { get; set; }

        private static string q { get; set; }
        private static string from { get; set; }
        private static string to { get; set; }


        //字段名	类型	必填参数	描述	备注
        //q	TEXT	Y	请求翻译query	UTF-8编码
        //from	TEXT	Y	翻译源语言	语言列表(可设置为auto)
        //to	TEXT	Y	译文语言	语言列表(不可设置为auto)
        //appid	INT	Y	APP ID	可在管理控制台查看
        //salt	INT	Y	随机数	
        //sign	TEXT	Y	签名	appid+q+salt+密钥 的MD5值

        private static Random rd = new Random();

        /// <summary>
        /// DateTime时间格式转换为10位不带毫秒的Unix时间戳
        /// </summary>
        /// <param name="time"> DateTime时间格式</param>
        /// <returns>Unix时间戳格式</returns>
        public static int ConvertDateTimeInt(System.DateTime time)
        {
            System.DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1));
            return (int)(time - startTime).TotalSeconds;
        }

        public static string Translate(string words)
        {
            q = words.Trim();
            from = "en";
            to = "zh";
            salt = ConvertDateTimeInt(DateTime.Now).ToString();

            if (isChinese(q))
            {
                to = "en";
                from = "zh";
            }

            using (System.Net.WebClient web = new System.Net.WebClient())
            {
                web.Encoding = Encoding.UTF8;
                var url = string.Format(APIURL, q, from, to, appid, salt, getSing());

                var result = Regex.Unescape(web.DownloadString(url));

                return result;
            }






        }


        public static bool isChinese(string word)
        {
            for (int i = 0; i < word.Length; i++)
            {
                if ((int)word[i] > 127)
                    return true;
                else
                    return false;
            }
            return false;
        }

        private static string getSing()
        {

            return GetMD5(appid + q + salt + token);

        }

        private static string GetMD5(string myString)
        {

            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] fromData = System.Text.Encoding.UTF8.GetBytes(myString);
            byte[] targetData = md5.ComputeHash(fromData);
            string byte2String = null;

            for (int i = 0; i < targetData.Length; i++)
            {
                byte2String += targetData[i].ToString("x");
            }

            return byte2String;
        }


    }
}
