﻿using MyTranslation.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MyTranslation
{
    [System.Runtime.InteropServices.ComVisibleAttribute(true)]
    public partial class FrmHistory : Form
    {
        private int currentPage = 1;
        public FrmHistory()
        {
            InitializeComponent();

        }

        private Dictionary<string, Dict> data;
        private void FrmHistory_Load_1(object sender, EventArgs e)
        {
            this.listView1.Columns.Add("word", 150);
            listView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            listView1.FullRowSelect = true;
            getpage(1, 10);
        }


        public void reload()
        {
            getpage(1, 10);
        }
        private void getpage(int page, int count)
        {
            listView1.Items.Clear();
            data = IcibaAPI.History(page, count);
            foreach (var item in data)
            {
                listView1.Items.Add(item.Key);

            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (listView1.SelectedItems.Count > 0)
            {
                Font fOld = new Font(Control.DefaultFont, FontStyle.Regular);

                foreach (ListViewItem lvi in listView1.Items)
                {
                    lvi.BackColor = Color.White;
                    lvi.Font = fOld;

                }


                //修改选中项颜色
                listView1.SelectedItems[0].SubItems[0].BackColor = Color.WhiteSmoke;

                //加粗字体
                Font f = new Font(Control.DefaultFont, FontStyle.Bold);
                listView1.SelectedItems[0].SubItems[0].Font = f;

                var key = listView1.SelectedItems[0].SubItems[0].Text;
                //去掉选中项背景
                listView1.SelectedItems[0].Selected = false;

                if (data.ContainsKey(key))
                {
                    string result = "";
                    Dict dict = data[key];
                    if (dict.en != "" || dict.am != "")
                    {
                        result += "英[" + dict.en + "]  美[" + dict.am + "]\r\n";
                    }

                    result += dict.means;

                    this.textBox1.Text = result;
                }
                else
                {
                    this.textBox1.Text = "";
                }

            }
        }

        private void 上一页ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            currentPage--;

            if (currentPage == 0)
            {
                return;
            }
            getpage(currentPage, 10);
        }

        private void 下一页ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            currentPage++;

            if (currentPage == 0)
            {
                return;
            }
            getpage(currentPage, 10);
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            currentPage--;

            if (currentPage == 0)
            {
                return;
            }
            getpage(currentPage, 10);
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            currentPage++;

            if (currentPage == 0)
            {
                return;
            }
            getpage(currentPage, 10);
        }



    }
}
