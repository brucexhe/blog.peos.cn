﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyTranslation
{
    public class DictAPI
    {
        static MySqlConnection con;
        static DictAPI()
        {
            string conn = "Data Source=127.0.0.1;User ID=root;Password=Long123456;DataBase=yinhan_dict";
            con = new MySqlConnection(conn);

        }

        public static Dictionary<string, string> History(int page, int count)
        {
            Dictionary<string, string> result = new Dictionary<string, string>();
            if (con.State != System.Data.ConnectionState.Open)
            {
                con.Open();
            }

            string sql = "select b.word,b.explain from history a left join mydict b on a.word = b.word limit " + (page - 1) * count + "," + count + "";

            MySqlCommand cmd = new MySqlCommand(sql, con);
            MySqlDataReader dr = cmd.ExecuteReader();
            //操作dr中的数据
            while (dr.HasRows)
            {
                if (dr.Read())
                {
                    result.Add(dr["word"].ToString(), dr["explain"].ToString());
                }
                else
                {
                    break;
                }
            }

            dr.Close();
            con.Close();
            return result;
        }

        public static List<string> Select(string word)
        {
            List<string> result = new List<string>();
            if (con.State != System.Data.ConnectionState.Open)
            {
                con.Open();
            }

            MySqlCommand cmd = new MySqlCommand("select * from mydict where word like '" + word + "%'", con);
            MySqlDataReader dr = cmd.ExecuteReader();
            //操作dr中的数据
            while (dr.HasRows)
            {
                if (dr.Read())
                {
                    result.Add(dr["word"].ToString());
                }
            }

            dr.Close();
            con.Close();
            return result;
        }

        public static string Translate(string word)
        {
            string result = "";
            if (con.State != System.Data.ConnectionState.Open)
            {
                con.Open();
            }

            MySqlCommand cmd = new MySqlCommand("select * from mydict where word like '" + word + "%'", con);
            MySqlDataReader dr = cmd.ExecuteReader();
            //操作dr中的数据
            while (dr.HasRows)
            {
                if (dr.Read())
                {
                    result = dr["explain"].ToString();

                    string db_word = dr["word"].ToString().Trim();

                    dr.Close();

                    if (word == db_word)
                    {
                        addHistory(word);
                    }

                    break;
                }
            }

            con.Close();
            return result;

        }

        public static void addHistory(string word)
        {
            string sql = "select 1 from history where word='" + word + "'";
            MySqlCommand cmd = new MySqlCommand(sql, con);
            Object obj = cmd.ExecuteScalar();
            if (obj != null)
            {
                sql = "update history set count=count+1,time = '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where word='" + word + "'";
            }
            else
            {
                sql = "insert into history values('" + word + "',1,'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
            }

            cmd = new MySqlCommand(sql, con);
            cmd.ExecuteNonQuery();
        } 
    }
}
