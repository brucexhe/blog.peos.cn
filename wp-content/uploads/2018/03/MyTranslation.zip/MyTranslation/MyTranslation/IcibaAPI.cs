﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using MySql.Data.MySqlClient;
using MyTranslation.Model;


namespace MyTranslation
{
    public class IcibaAPI
    {
        private static string APIURL = "http://www.iciba.com/index.php?a=getWordMean&c=search&list=1&word={0}&_={1}";


        static MySqlConnection con;
        static IcibaAPI()
        {
            string conn = "Data Source=127.0.0.1;User ID=root;Password=Long123456;DataBase=yinhan_dict";
            con = new MySqlConnection(conn);

        }



        public static string Translate(string words)
        {
            string newword = words;
            string result = "";
            string en = "";
            string am = "";
            string read = "";


            using (System.Net.WebClient web = new System.Net.WebClient())
            {
                web.Encoding = Encoding.UTF8;
                words = System.Web.HttpUtility.UrlEncode(words);
                var url = string.Format(APIURL, words, DateTime.Now.Ticks);

                var apiResult = Regex.Unescape(web.DownloadString(url));
                //{"errno":404,"errmsg":"无释义"}
                if (apiResult.Contains("404"))
                {
                    return "Not Found";
                }


                JObject json = JObject.Parse(apiResult);

                string translate_type = json.SelectToken("baesInfo.translate_type").ToString();
                if (translate_type == "2")
                {
                    result = json.SelectToken("baesInfo.translate_result").ToString();
                }
                else if (translate_type == "1")
                {
                    en = json.SelectToken("baesInfo.symbols[0].ph_en").ToStringOrEmpty();
                    am = json.SelectToken("baesInfo.symbols[0].ph_am").ToStringOrEmpty();
                    if (am != "" || en != "")
                    {
                        read = "英[" + en + "]  美[" + am + "]\r\n";
                    }
                    //[0].means
                    var parts = json.SelectToken("baesInfo.symbols[0].parts");
                    foreach (var part in parts)
                    {
                        var means = part.SelectToken("means");
                        var meanString = "";
                        foreach (var mean in means)
                        {
                            meanString += mean.ToString() + "，";
                        }
                        result += part.SelectToken("part") + " " + meanString + "\r\n";
                    }

                }

                addHistory(newword, result, en, am);

                return read + result;
            }
        }


        public static void addHistory(string word, string means, string en, string am)
        {
            if (con.State != System.Data.ConnectionState.Open)
            {
                con.Open();
            }
            word = word.Replace("'","''");
            string sql = "select 1 from history where word='" + word + "'";
            MySqlCommand cmd = new MySqlCommand(sql, con);
            Object obj = cmd.ExecuteScalar();
            if (obj != null)
            {
                sql = "update history set count=count+1,time = '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where word='" + word + "'";
            }
            else
            {
                sql = "insert into history values('" + word + "',1,'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','" + means + "','" + en + "','" + am + "')";
            }

            cmd = new MySqlCommand(sql, con);
            cmd.ExecuteNonQuery();
        }


        public static Dictionary<string, Dict> History(int page, int count)
        {
            Dictionary<string, Dict> result = new Dictionary<string, Dict>();
            if (con.State != System.Data.ConnectionState.Open)
            {
                con.Open();
            }

            string sql = "select word,means,en,am from history where time >'" + DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd HH:mm:ss") + "' order by time desc limit " + (page - 1) * count + "," + count + "";

            MySqlCommand cmd = new MySqlCommand(sql, con);
            MySqlDataReader dr = cmd.ExecuteReader();
            //操作dr中的数据
            while (dr.HasRows)
            {
                if (dr.Read())
                {
                    result.Add(dr["word"].ToString(), new Dict()
                    {
                        word = dr["word"].ToString(),
                        means = dr["means"].ToString(),
                        en = dr["en"].ToString(),
                        am = dr["am"].ToString(),
                    });
                }
                else
                {
                    break;
                }
            }

            dr.Close();
            con.Close();
            return result;
        }
    }
}
