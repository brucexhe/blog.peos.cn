using System;
using System.IO;
using System.Text;

namespace Search.Lib
{
	public class FileUtil
	{
		public static string GetAbsolutePath(string path)
		{
			string currentpath = System.AppDomain.CurrentDomain.BaseDirectory;
			string result;
			if (string.IsNullOrEmpty(path))
			{
				result = currentpath;
			}
			else
			{
				string apath = path;
				if (apath.StartsWith("/"))
				{
					apath = apath.Substring(1);
				}
				apath = apath.Replace('/', '\\');
				result = currentpath + apath;
			}
			return result;
		}

		public static void MakeFolder(string path)
		{
			System.IO.DirectoryInfo folder = new System.IO.DirectoryInfo(path);
			if (!folder.Exists)
			{
				folder.Create();
			}
		}

		public static void DelFolder(string path)
		{
			System.IO.DirectoryInfo folder = new System.IO.DirectoryInfo(path);
			try
			{
				folder.Delete(true);
			}
			catch (System.Exception e_14)
			{
			}
		}

		public static bool FileExits(string path)
		{
			return System.IO.File.Exists(path);
		}

		public static void DelFile(string path)
		{
			try
			{
				System.IO.File.Delete(path);
			}
			catch (System.Exception e_0C)
			{
			}
		}

		public static void ReadWriteStream(System.IO.Stream readStream, System.IO.Stream writeStream)
		{
			int Length = 256;
			byte[] buffer = new byte[Length];
			for (int bytesRead = readStream.Read(buffer, 0, Length); bytesRead > 0; bytesRead = readStream.Read(buffer, 0, Length))
			{
				writeStream.Write(buffer, 0, bytesRead);
			}
			readStream.Close();
			writeStream.Close();
		}

		public static string ReadFile(string FileName)
		{
			string ret = "";
			System.IO.FileStream files = null;
			try
			{
				files = new System.IO.FileStream(FileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
				System.IO.StreamReader sr = new System.IO.StreamReader(files);
				ret = sr.ReadToEnd();
				sr.Close();
			}
			catch (System.Exception ex)
			{
				throw ex;
			}
			finally
			{
				if (files != null)
				{
					files.Close();
				}
			}
			return ret;
		}

		public static string ReadFile(string FileName, string Encode)
		{
			int readsize = 512;
			byte[] buffer = new byte[readsize];
			System.Text.StringBuilder sb = new System.Text.StringBuilder(readsize);
			System.IO.FileStream files = null;
			try
			{
				files = new System.IO.FileStream(FileName, System.IO.FileMode.Open);
				char[] charData = new char[files.Length];
				for (int reads = files.Read(buffer, 0, readsize); reads > 0; reads = files.Read(buffer, 0, readsize))
				{
					sb.Append(System.Text.Encoding.GetEncoding(Encode).GetChars(buffer, 0, reads));
				}
			}
			catch (System.Exception ex)
			{
				throw ex;
			}
			finally
			{
				if (files != null)
				{
					files.Close();
				}
			}
			return sb.ToString();
		}

		public static void WriteFile(string FileName, string content)
		{
			byte[] data = System.Text.Encoding.UTF8.GetBytes(content);
			System.IO.FileStream file = null;
			try
			{
				file = new System.IO.FileStream(FileName, System.IO.FileMode.Create);
				file.Write(data, 0, data.Length);
			}
			catch (System.Exception ex)
			{
				throw ex;
			}
			finally
			{
				if (file != null)
				{
					file.Close();
				}
			}
		}
	}
}
