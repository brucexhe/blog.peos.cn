using System;
using System.Text;
using System.Text.RegularExpressions;

namespace Search.Lib
{
    public static class StringUtil
    {
        public static string ToStringOrEmpty(this string text)
        {
            if (text == null)
            {
                return string.Empty;
            }
            return text.ToString();
        }

        public static int ToInt32(this string text)
        {
            if (text == null)
            {
                return 0;
            }

            int result = 0;
            Int32.TryParse(text, out result);
            return result;
        }


        public static string RemoveHtml(string text)
        {
            return Regex.Replace(text, "<(.|\\n)*?>", string.Empty);
        }

        public static string HtmlSafe(string text)
        {
            string result;
            if (string.IsNullOrEmpty(text))
            {
                result = "";
            }
            else
            {
                text = text.Replace("&", "&amp;");
                text = text.Replace("<", "&lt;");
                text = text.Replace(">", "&gt;");
                text = text.Replace("\r", string.Empty);
                result = text;
            }
            return result;
        }

        public static string Replace(string soure, string oldstr, string newstr)
        {
            string result;
            if (string.IsNullOrEmpty(soure))
            {
                result = "";
            }
            else if (string.IsNullOrEmpty(oldstr))
            {
                result = soure;
            }
            else
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder(1024);
                int lensource = soure.Length;
                int lenold = oldstr.Length;
                int postart = 0;
                for (int pos = soure.IndexOf(oldstr, postart, System.StringComparison.InvariantCultureIgnoreCase); pos >= 0; pos = soure.IndexOf(oldstr, postart, System.StringComparison.InvariantCultureIgnoreCase))
                {
                    sb.Append(soure.Substring(postart, pos - postart));
                    sb.Append(newstr);
                    postart = pos + lenold;
                }
                if (postart < lensource)
                {
                    sb.Append(soure.Substring(postart));
                }
                result = sb.ToString();
            }
            return result;
        }
    }
}
