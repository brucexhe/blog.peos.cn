using System;
using System.Data;
using System.Data.OleDb;

namespace Search.Lib
{
	public class TableDao
	{
		public static TableDao Instance
		{
			get
			{
				return Singleton<TableDao>.Instance;
			}
		}

		public void TestConn(string connstr)
		{
			OleDbConnection conn = null;
			try
			{
				conn = new OleDbConnection(connstr);
				conn.Open();
			}
			catch (System.Exception er)
			{
				throw new System.Exception(er.ToString());
			}
			finally
			{
				if (conn.State != ConnectionState.Closed)
				{
					conn.Close();
				}
			}
		}

		public void Exe(string sql, string connstr)
		{
			OleDbConnection conn = null;
			try
			{
				conn = new OleDbConnection(connstr);
				conn.Open();
				OleDbCommand cmd = new OleDbCommand(sql, conn);
				cmd.ExecuteNonQuery();
			}
			catch (System.Exception er)
			{
				throw new System.Exception(er.ToString());
			}
			finally
			{
				if (conn.State != ConnectionState.Closed)
				{
					conn.Close();
				}
			}
		}

		public string GetKeyName(string tbname, string connstr)
		{
			string ret = "";
			OleDbConnection conn = null;
			OleDbDataReader reader = null;
			try
			{
				conn = new OleDbConnection(connstr);
				conn.Open();
				OleDbCommand cmd = new OleDbCommand("select keyname from index_table where tbname='" + tbname + "'", conn);
				reader = cmd.ExecuteReader();
				if (reader.Read())
				{
					ret = reader[0].ToString();
				}
			}
			catch (System.Exception e)
			{
				throw new System.Exception(e.ToString());
			}
			finally
			{
				if (reader != null)
				{
					reader.Close();
				}
				if (conn.State != ConnectionState.Closed)
				{
					conn.Close();
				}
			}
			return ret;
		}

		public DataField Get(int id, string connstr)
		{
			DataField df = null;
			OleDbConnection conn = null;
			OleDbDataReader reader = null;
			string fields = "tbname,keyname,title,classid,photo,demons,content,moditime,linkurl";
			try
			{
				conn = new OleDbConnection(connstr);
				conn.Open();
				OleDbCommand cmd = new OleDbCommand(string.Concat(new object[]
				{
					"select ",
					fields,
					" from index_table where id=",
					id
				}), conn);
				reader = cmd.ExecuteReader();
				string[] fieldArr = fields.Split(new char[]
				{
					','
				});
				if (reader.Read())
				{
					df = new DataField();
					for (int i = 0; i < fieldArr.Length; i++)
					{
						df.SetFieldValue(fieldArr[i], reader[i]);
					}
				}
			}
			catch (System.Exception e_BD)
			{
			}
			finally
			{
				if (reader != null)
				{
					reader.Close();
				}
				if (conn.State != ConnectionState.Closed)
				{
					conn.Close();
				}
			}
			return df;
		}

		public DataField Get(string tbname, string connstr)
		{
			DataField df = null;
			OleDbConnection conn = null;
			OleDbDataReader reader = null;
			string fields = "tbname,keyname,title,classid,photo,demons,content,moditime,linkurl";
			try
			{
				conn = new OleDbConnection(connstr);
				conn.Open();
				OleDbCommand cmd = new OleDbCommand(string.Concat(new string[]
				{
					"select ",
					fields,
					" from index_table where tbname='",
					tbname,
					"'"
				}), conn);
				reader = cmd.ExecuteReader();
				string[] fieldArr = fields.Split(new char[]
				{
					','
				});
				if (reader.Read())
				{
					df = new DataField();
					for (int i = 0; i < fieldArr.Length; i++)
					{
						df.SetFieldValue(fieldArr[i], reader[i]);
					}
				}
			}
			catch (System.Exception e_C1)
			{
			}
			finally
			{
				if (reader != null)
				{
					reader.Close();
				}
				if (conn.State != ConnectionState.Closed)
				{
					conn.Close();
				}
			}
			return df;
		}

		public DataTable GetDataTable(string connstr)
		{
			OleDbConnection conn = null;
			DataTable ret = null;
			DataSet ds = new DataSet();
			try
			{
				conn = new OleDbConnection(connstr);
				conn.Open();
				OleDbCommand cmd = new OleDbCommand("select id,tbname,keyname,title,classid,photo,demons,content,moditime,linkurl from index_table", conn);
				using (OleDbDataAdapter da = new OleDbDataAdapter())
				{
					da.SelectCommand = cmd;
					da.SelectCommand.Connection = cmd.Connection;
					da.Fill(ds);
					ret = ds.Tables[0];
				}
			}
			catch (System.Exception er)
			{
				throw new System.Exception(er.ToString());
			}
			finally
			{
				if (conn.State != ConnectionState.Closed)
				{
					conn.Close();
				}
			}
			return ret;
		}
	}
}
