using System;
using System.IO;
using System.Text;
using System.Web;
using System.Web.Caching;
using System.Web.UI;

namespace Search.Lib
{
	public class Template
	{
		private System.Text.StringBuilder templateFile;

		public Template()
		{
			this.templateFile = new System.Text.StringBuilder("");
		}

		public Template(string templateName, Page hostPage)
		{
			this.templateFile = new System.Text.StringBuilder(Template.GetTemplate(templateName, hostPage));
		}

		public void ProcessesVariable(string templateVar, string value)
		{
			this.templateFile.Replace(templateVar, value);
			string partialVar = templateVar.Substring(0, templateVar.Length - 2) + "|";
			string textOutput = this.templateFile.ToString();
			for (int start = textOutput.IndexOf(partialVar); start != -1; start = textOutput.IndexOf(partialVar))
			{
				string varFuncs = textOutput.Substring(start + partialVar.Length, textOutput.IndexOf("$]", start) - start - partialVar.Length);
				string valueMod = value;
				string[] array = varFuncs.Split(new char[]
				{
					'|'
				});
				for (int i = 0; i < array.Length; i++)
				{
					string func = array[i];
					string text = func.ToUpper();
					if (text != null)
					{
						if (!(text == "UPPER"))
						{
							if (!(text == "LOWER"))
							{
								if (!(text == "ESCAPE"))
								{
									if (!(text == "DOUBLEESCAPE"))
									{
										if (text == "ENCODE")
										{
											valueMod = HttpUtility.UrlEncode(valueMod);
										}
									}
									else
									{
										valueMod = valueMod.Replace("\"", "\\\"");
									}
								}
								else
								{
									valueMod = valueMod.Replace("'", "\\'");
								}
							}
							else
							{
								valueMod = valueMod.ToLower();
							}
						}
						else
						{
							valueMod = valueMod.ToUpper();
						}
					}
				}
				this.templateFile.Replace(partialVar + varFuncs + "$]", valueMod);
				textOutput = this.templateFile.ToString();
			}
		}

		public void ProcessesVariable(string templateVar, int value)
		{
			this.templateFile.Replace(templateVar, value.ToString());
			string partialVar = templateVar.Substring(0, templateVar.Length - 2) + "|";
			string textOutput = this.templateFile.ToString();
			for (int start = textOutput.IndexOf(partialVar); start != -1; start = textOutput.IndexOf(partialVar))
			{
				string varFuncs = textOutput.Substring(start + partialVar.Length, textOutput.IndexOf("$]", start) - start - partialVar.Length);
				int valueMod = value;
				string[] array = varFuncs.Split(new char[]
				{
					'|'
				});
				for (int i = 0; i < array.Length; i++)
				{
					string func = array[i];
					string text = func.Substring(0, (func.IndexOf(":") == -1) ? func.Length : func.IndexOf(":")).ToUpper();
					if (text != null)
					{
						if (!(text == "DIV"))
						{
							if (!(text == "MUL"))
							{
								if (!(text == "ADD"))
								{
									if (text == "SUB")
									{
										valueMod -= int.Parse(func.Substring(func.IndexOf(":") + 1));
									}
								}
								else
								{
									valueMod += int.Parse(func.Substring(func.IndexOf(":") + 1));
								}
							}
							else
							{
								valueMod *= int.Parse(func.Substring(func.IndexOf(":") + 1));
							}
						}
						else
						{
							valueMod /= int.Parse(func.Substring(func.IndexOf(":") + 1));
						}
					}
				}
				this.templateFile.Replace(partialVar + varFuncs + "$]", valueMod.ToString());
				textOutput = this.templateFile.ToString();
			}
		}

		public void Append(string value)
		{
			this.templateFile.Append(value);
		}

		public string GetString()
		{
			return this.templateFile.ToString();
		}

		public static string GetTemplate(string templateName, Page hostPage)
		{
			System.Text.StringBuilder textOutput = new System.Text.StringBuilder();
			string returnValue = "";
			string templateDirectory = "";
			string cacheName = "totcms." + templateName;
			templateDirectory = hostPage.Server.MapPath("~/Template");
			try
			{
				textOutput = (System.Text.StringBuilder)hostPage.Cache.Get(cacheName);
				if (textOutput == null)
				{
					string filePath = templateDirectory + "\\" + templateName;
					System.IO.StreamReader objReader = new System.IO.StreamReader(filePath);
					textOutput = new System.Text.StringBuilder();
					textOutput.Append(objReader.ReadToEnd());
					objReader.Close();
					hostPage.Cache.Insert(cacheName, textOutput, new CacheDependency(filePath));
				}
				returnValue = textOutput.ToString();
			}
			catch (System.Exception exc)
			{
				try
				{
					hostPage.Response.Write(string.Concat(new string[]
					{
						"Error loading a template file: ",
						templateName,
						" from ",
						templateDirectory,
						".<br>Please check the permissions on the directory and try again.<br><br>Exception was: ",
						exc.Message
					}));
					hostPage.Response.End();
				}
				catch
				{
				}
			}
			return returnValue;
		}
	}
}
