using System;
using System.Text;

namespace Search.Lib
{
	public static class DateUtil
	{
		public static string GetNowString(System.DateTime now)
		{
			return now.ToString();
		}

		public static string GetDateNumString()
		{
			System.DateTime now = System.DateTime.Now;
			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			sb.Append(now.Year);
			sb.Append(now.Month);
			sb.Append(now.Day);
			sb.Append(now.Hour);
			sb.Append(now.Minute);
			sb.Append(now.Second);
			sb.Append(now.Millisecond);
			return sb.ToString();
		}

		public static string GetTimeNumString()
		{
			System.DateTime now = System.DateTime.Now;
			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			sb.Append(now.Hour);
			sb.Append(now.Minute);
			sb.Append(now.Second);
			sb.Append(now.Millisecond);
			return sb.ToString();
		}

		public static string GetShortDateString()
		{
			return DateUtil.DateFormat("{0:yyyy-MM-dd}");
		}

		public static string GetLongDateString()
		{
			return DateUtil.DateFormat("{0:yyyy-MM-dd HH:mm:ss}");
		}

		public static string DateFormat(string pattern)
		{
			System.DateTime now = System.DateTime.Now;
			return string.Format(pattern, now);
		}

		public static System.DateTime GetDate(string datestr)
		{
			System.DateTime d = System.DateTime.MinValue;
			System.DateTime result;
			try
			{
				d = System.Convert.ToDateTime(datestr);
			}
			catch (System.FormatException e_12)
			{
				result = System.DateTime.MinValue;
				return result;
			}
			result = d;
			return result;
		}

		public static string GetFormat(string datestr, string formatstr)
		{
			System.DateTime d = DateUtil.GetDate(datestr);
			return string.Format(formatstr, d);
		}
	}
}
