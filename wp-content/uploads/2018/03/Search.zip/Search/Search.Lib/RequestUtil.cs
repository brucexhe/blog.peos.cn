using System;

namespace Search.Lib
{
	public class RequestUtil
	{
		public static int getInt(string para)
		{
			int result;
			if (string.IsNullOrEmpty(para))
			{
				result = 0;
			}
			else
			{
				result = System.Convert.ToInt32(para);
			}
			return result;
		}

		public static long getLong(string para)
		{
			long result;
			if (string.IsNullOrEmpty(para))
			{
				result = 0L;
			}
			else
			{
				result = long.Parse(para);
			}
			return result;
		}

		public static System.DateTime getDate(string para)
		{
			System.DateTime result;
			if (string.IsNullOrEmpty(para))
			{
				result = System.DateTime.Now;
			}
			else
			{
				result = System.DateTime.Parse(para);
			}
			return result;
		}
	}
}
