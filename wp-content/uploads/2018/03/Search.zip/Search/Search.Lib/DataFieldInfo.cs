using System;

namespace Search.Lib
{
	public class DataFieldInfo
	{
		private string _tablename;

		private string _keyname;

		private string _id;

		private string _title;

		private string _categoryid;

		private string _linkurl;

		private string _summary;

		private string _content;

		private string _moddate;

		private string _photo;

		public string TableName
		{
			get
			{
				return this._tablename;
			}
			set
			{
				this._tablename = value;
			}
		}

		public string KeyName
		{
			get
			{
				return this._keyname;
			}
			set
			{
				this._keyname = value;
			}
		}

		public string Id
		{
			get
			{
				return this._id;
			}
			set
			{
				this._id = value;
			}
		}

		public string Title
		{
			get
			{
				return this._title;
			}
			set
			{
				this._title = value;
			}
		}

		public string CategoryId
		{
			get
			{
				return this._categoryid;
			}
			set
			{
				this._categoryid = value;
			}
		}

		public string LinkUrl
		{
			get
			{
				return this._linkurl;
			}
			set
			{
				this._linkurl = value;
			}
		}

		public string Summary
		{
			get
			{
				return this._summary;
			}
			set
			{
				this._summary = value;
			}
		}

		public string Content
		{
			get
			{
				return this._content;
			}
			set
			{
				this._content = value;
			}
		}

		public string ModDate
		{
			get
			{
				return this._moddate;
			}
			set
			{
				this._moddate = value;
			}
		}

		public string Photo
		{
			get
			{
				return this._photo;
			}
			set
			{
				this._photo = value;
			}
		}

		public DataFieldInfo()
		{
			this.TableName = "";
			this.KeyName = "id";
			this.Id = "0";
			this.Title = "";
			this.CategoryId = "0";
			this.Content = "";
			this.Summary = "";
			this.ModDate = "";
			this.Photo = "";
			this.LinkUrl = "";
		}
	}
}
