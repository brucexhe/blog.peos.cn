using System;
using System.Collections.Generic;

namespace Search.Lib
{
	public class DataField
	{
		private readonly System.Collections.Generic.Dictionary<string, DataBean> _fields = new System.Collections.Generic.Dictionary<string, DataBean>();

		public object GetFieldValue(string fieldname)
		{
			return this._fields[fieldname].DataValue;
		}

		public string GetFieldStr(string fieldname)
		{
			return this._fields[fieldname].DataValue.ToString();
		}

		public void SetFieldValue(string fieldname, object fieldvalue)
		{
			if (!this._fields.ContainsKey(fieldname))
			{
				this._fields[fieldname] = new DataBean(fieldname, fieldvalue);
			}
		}
	}
}
