using System;

namespace Search.Lib
{
	public class DataBean
	{
		private string _dataname;

		private object _datavalue;

		public string DataName
		{
			get
			{
				return this._dataname;
			}
			set
			{
				this._dataname = value;
			}
		}

		public object DataValue
		{
			get
			{
				return this._datavalue;
			}
			set
			{
				this._datavalue = value;
			}
		}

		public DataBean(string d, object v)
		{
			this._dataname = d;
			this._datavalue = v;
		}
	}
}
