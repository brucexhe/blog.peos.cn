using System;

namespace Search.Lib
{
	public class ObjectFactory
	{
		protected SingleClassInstanceFactory _singleInstanceFactory = new SingleClassInstanceFactory();

		public static ObjectFactory Instance
		{
			get
			{
				return Singleton<ObjectFactory>.Instance;
			}
		}

		public IndexUtil GetIndexUtil
		{
			get
			{
				return this._singleInstanceFactory.GetInstance<IndexUtil>();
			}
		}

		public SearchUtil GetSearchUtil
		{
			get
			{
				return this._singleInstanceFactory.GetInstance<SearchUtil>();
			}
		}
	}
}
