using System;
using System.Collections.Generic;

namespace Search.Lib
{
	public class SingleClassInstanceFactory
	{
		private readonly System.Collections.Generic.Dictionary<int, object> _contextClasses = new System.Collections.Generic.Dictionary<int, object>();

		public T GetInstance<T>() where T : class
		{
			int objNameHash = typeof(T).ToString().GetHashCode();
			if (!this._contextClasses.ContainsKey(objNameHash))
			{
				this._contextClasses[objNameHash] = (T)((object)System.Activator.CreateInstance(typeof(T), true));
			}
			return (T)((object)this._contextClasses[objNameHash]);
		}

		public void SetInstance<T>(T instance) where T : class
		{
			int objNameHash = typeof(T).ToString().GetHashCode();
			this._contextClasses[objNameHash] = instance;
		}
	}
}
