﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Search.Lib
{
    public static class SQLFilterUtil
    {
        private static string[] tstr = new string[]
		{
			"=",
			";",
			"'",
			"\\",
			"+",
			"-",
			"&&",
			"||",
			"!",
			"(",
			")",
			"{",
			"}",
			"[",
			"]",
			"^",
			"\"",
			"~",
			"*",
			"?",
			":"
		};

        public static string Filter(this string str)
        {
            for (int i = 0; i < tstr.Length; i++)
            {
                str = str.Replace(tstr[i], " ");
            }
            return str;
        }
    }
}
