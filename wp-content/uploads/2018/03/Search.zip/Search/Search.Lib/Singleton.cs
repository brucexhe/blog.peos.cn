using System;

namespace Search.Lib
{
	public static class Singleton<T> where T : class, new()
	{
		private static T _instance;

		public static T Instance
		{
			get
			{
				return Singleton<T>.GetInstance();
			}
			private set
			{
				Singleton<T>._instance = value;
			}
		}

		private static T GetInstance()
		{
			if (Singleton<T>._instance == null)
			{
				Singleton<T>._instance = (T)((object)System.Activator.CreateInstance(typeof(T), true));
			}
			return Singleton<T>._instance;
		}
	}
}
