using System;
using System.Configuration;
using System.Web.Configuration;

namespace Search.Lib
{
	public static class ConfigUtil
	{
		private static string admconn = "";

		public static int MergeFactor
		{
			get
			{
				return 10;
			}
		}

		public static int MaxBufferedDoc
		{
			get
			{
				return 500;
			}
		}

		public static int MaxFieldLength
		{
			get
			{
				return 1000;
			}
		}

		public static string IKey
		{
			get
			{
				return ConfigUtil.GetConfigValueAsString("ikey");
			}
		}

		public static string ConnectionString
		{
			get
			{
				string ret = "";
				string dbtype = ConfigUtil.DbType;
				string text = dbtype;
				if (text != null)
				{
					if (!(text == "Access"))
					{
						if (text == "Mssql")
						{
							ret = string.Concat(new string[]
							{
								"Provider=SQLOLEDB;server=",
								ConfigUtil.DbIp,
								";database=",
								ConfigUtil.DbName,
								";uid=",
								ConfigUtil.DbUserName,
								";pwd=",
								ConfigUtil.DbPassword
							});
						}
					}
					else
					{
						ret = "provider=microsoft.jet.oledb.4.0;data source=" + ConfigUtil.DbIp;
					}
				}
				return ret;
			}
		}

		public static string DbType
		{
			get
			{
				return ConfigUtil.GetConfigValueAsString("db.type");
			}
		}

		public static string DbIp
		{
			get
			{
				return ConfigUtil.GetConfigValueAsString("db.ip");
			}
		}

		public static string DbName
		{
			get
			{
				return ConfigUtil.GetConfigValueAsString("db.name");
			}
		}

		public static string DbUserName
		{
			get
			{
				return ConfigUtil.GetConfigValueAsString("db.username");
			}
		}

		public static string DbPassword
		{
			get
			{
				return ConfigUtil.GetConfigValueAsString("db.password");
			}
		}

		public static string ManageUserName
		{
			get
			{
				return ConfigUtil.GetConfigValueAsString("manage.userid");
			}
		}

		public static string ManagePassword
		{
			get
			{
				return ConfigUtil.GetConfigValueAsString("manage.password");
			}
		}

		public static string GetConfigValueAsString(string configKey)
		{
			string[] allKeys = WebConfigurationManager.AppSettings.AllKeys;
			string result;
			for (int i = 0; i < allKeys.Length; i++)
			{
				string key = allKeys[i];
				if (key.Equals(configKey, System.StringComparison.CurrentCultureIgnoreCase))
				{
					result = ConfigurationManager.AppSettings[key];
					return result;
				}
			}
			result = null;
			return result;
		}

		public static bool GetConfigValueAsBool(string configKey, bool defaultValue)
		{
			string value = ConfigUtil.GetConfigValueAsString(configKey);
			bool result;
			if (!string.IsNullOrEmpty(value))
			{
				result = System.Convert.ToBoolean(value.ToLower());
			}
			else
			{
				result = defaultValue;
			}
			return result;
		}

		public static int GetConfigValueAsInt(string configKey, int defaultValue)
		{
			string value = ConfigUtil.GetConfigValueAsString(configKey);
			int result;
			if (!string.IsNullOrEmpty(value))
			{
				result = System.Convert.ToInt32(value.ToLower());
			}
			else
			{
				result = defaultValue;
			}
			return result;
		}
	}
}
