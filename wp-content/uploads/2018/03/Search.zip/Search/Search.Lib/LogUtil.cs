﻿using log4net;
using System;
using System.Reflection;

namespace Search.Lib
{
    public static class LogUtil
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static void Debug(string msg)
        {
            LogUtil.log.Debug(msg);
        }

        public static void Info(string msg)
        {
            LogUtil.log.Info(msg);
        }
    }
}
