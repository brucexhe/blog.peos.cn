﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Search.Lib;

namespace Search.Web.Controllers
{
    public class AjaxController : Controller
    {
        //
        // GET: /Ajax/

        public ActionResult Suggest()
        {
            string result = "";
            Response.ContentType = "text/plain";
            string str = Request.QueryString["parms"].ToStringOrEmpty();
            string t = Request.QueryString["t"];
            if (str.Length != 0)
            {
                string url = "http://suggestion.baidu.com/su?wd=" + str + "&p=3&cb=window.bdsug.sug&t=" + t;
                result = GetPage(url, System.Text.Encoding.GetEncoding("gb2312"));
                if (!string.IsNullOrEmpty(result))
                {
                    int start = result.IndexOf('[');
                    int end = result.IndexOf(']');
                    result = result.Substring(start + 1, end - start - 1);
                    result = result.Replace("\"", "");
                }
                //Response.Write(gets);
            }
            result = result.Replace("\"","");
            return Content(result);
        }

        public static string GetPage(string url, System.Text.Encoding encoding)
        {
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            System.IO.StreamReader reader = null;
            string result;
            try
            {
                request = (HttpWebRequest)WebRequest.Create(url);
                request.UserAgent = "www.baidu.com";
                request.Timeout = 20000;
                request.AllowAutoRedirect = false;
                response = (HttpWebResponse)request.GetResponse();
                if (response.StatusCode == HttpStatusCode.OK && response.ContentLength < 1048576L)
                {
                    reader = new System.IO.StreamReader(response.GetResponseStream(), encoding);
                    string html = reader.ReadToEnd();
                    result = html;
                    return result;
                }
            }
            catch
            {
            }
            finally
            {
                if (response != null)
                {
                    response.Close();
                    response = null;
                }
                if (reader != null)
                {
                    reader.Close();
                }
                if (request != null)
                {
                    request = null;
                }
            }
            result = string.Empty;
            return result;
        }


    }
}
