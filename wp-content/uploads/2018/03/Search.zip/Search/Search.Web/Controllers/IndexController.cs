﻿using Search.Lib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Search.Web.Controllers
{
    public class IndexController : Controller
    {
        //
        // GET: /Index/

        public ActionResult Index()
        {
            string text = Request.QueryString["q"].ToStringOrEmpty().Trim();
            if (string.IsNullOrWhiteSpace(text))
            {
                return View();
            }

            int pageIndex = Request.QueryString["page"].ToInt32();
            int count = Request.QueryString["num"].ToInt32();

            ViewBag.Results = ObjectFactory.Instance.GetSearchUtil.Search(text, pageIndex, count);
            ViewBag.Total = ObjectFactory.Instance.GetSearchUtil.ResultNum();

            return View();
        }


        public ActionResult Manage()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Manage(DataFieldInfo model)
        {
            try
            {
                ObjectFactory.Instance.GetIndexUtil.AddIndex(model);
                base.Response.Write("成功添加索引：" + model.Title);
            }
            catch (Exception EX)
            {

                throw EX;
            }


            return View("Manage");
        }

    }
}
