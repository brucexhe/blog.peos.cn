﻿var oInputField;    //考虑到很多函数中都要使用   
var oPopDiv;        //因此采用全局变量的形式   
var oconUl;
var currentIndex = -1;

$(function () {
    initVars();     //初始化变量  

    $("#q").keydown(function (e) {
        //if (key == 38) alert("按了↑键！");
        //if (key == 40) alert("按了↓键！");
        console.log(e);
        if (e.keyCode == 40) {
            oconUl.find('li').removeClass("mouseOver");
            var child = oconUl.find('li').length;
            if (child > 0) {
                currentIndex = currentIndex + 1;
                if (currentIndex >= child) {
                    currentIndex = 0;
                }

                var currentLi = oconUl.find("li:eq(" + currentIndex + ")");
                currentLi.addClass("mouseOver");

            }
            oInputField.val(currentLi.text());
            return;
        } else if (e.keyCode == 38) {
            oconUl.find('li').removeClass("mouseOver");
            var child = oconUl.find('li').length;
            if (child > 0) {
                currentIndex = currentIndex - 1;
                if (currentIndex < 0) {
                    currentIndex = child - 1;
                }

                var currentLi = oconUl.find("li:eq(" + currentIndex + ")");
                currentLi.addClass("mouseOver");

            }
            oInputField.val(currentLi.text());
            return;

        }
        findcon();
    });

    $("#q").click(function (e) {
        findcon();
    });
    $(window.document).click(function () {
        clearcon();
    });

});
function initVars() {
    //初始化变量   
    oInputField = $("#q");
    oPopDiv = $("#popup");
    oconUl = $("#con_ul");

    oPopDiv.css("width", oInputField.width());
}
function clearcon() {
    //清除提示内容   
    oconUl.empty();
    oPopDiv.removeClass("show");
}
function setcon(the_con) {
    //显示提示框，传入的参数即为匹配出来的结果组成的数组   
    clearcon(); //每输入一个字母就先清除原先的提示，再继续   
    oPopDiv.addClass("show");
    for (var i = 0; i < the_con.length; i++)
        //将匹配的提示结果逐一显示给用户   
        oconUl.append($("<li>" + the_con[i] + "</li>"));
    oconUl.find("li").click(function () {
        oInputField.val($(this).text());
        clearcon();
    }).hover(
        function () { $(this).addClass("mouseOver"); },
        function () { $(this).removeClass("mouseOver"); }
    );
}
function findcon() {
    if (oInputField.val().length > 0) {
        //获取异步数据   
        var url = "/Ajax/Suggest?parms=" + encodeURIComponent(oInputField.val());
        $.get(url, function (data) {
            var aResult = new Array();
            if (data.length > 0) {
                aResult = data.split(",");
                setcon(aResult);    //显示服务器结果   
            }
            else
                clearcon();
        });
    }
    else
        clearcon(); //无输入时清除提示框（例如用户按del键）   
}