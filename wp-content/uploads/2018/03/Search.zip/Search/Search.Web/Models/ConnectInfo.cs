﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Search.Web.Models
{
    public class ConnectInfo
    {
        public string DbServer { get; set; }
        public string DbName { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}