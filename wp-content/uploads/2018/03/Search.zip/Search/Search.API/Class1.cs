﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Search.API
{
    public class Class1
    {
    }
}
