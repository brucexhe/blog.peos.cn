#!/bin/bash
LogFile=/alidata/backup/log/`date +%Y%m%d`.log
#指定要备份的目录MAIL_DIR=mailbox       #邮件目录 
WEBSITE_DIR=/alidata/www                    #WEB目录 
DATABASE_DIR=/alidata/server/mysql-5.5.37/data                #数据库目录

#指定备份文件的前缀 
WEBSITE_PREFIX=web 
DATABASE_PREFIX=db

#备份文件存放目录 
BACKUP_DIR=/alidata/backup

#格式化一下日期，备份文件时用日期来做文件名的 
DATE=`date +%Y%m%d`

echo "backup `date +%Y%m%d` begin"  >> $LogFile

#开始备份网站目录，备份过程同上 
if [ -f ${BACKUP_DIR}/${WEBSITE_PREFIX}${DATE}.tar.gz ]; then 
    echo "`date +%Y-%m-%d`'s webebsite backup file is existing" >> $LogFile
else 
    tar -czvf ${BACKUP_DIR}/${WEBSITE_PREFIX}${DATE}.tar.gz ${SYSTEM_DIR}/${WEBSITE_DIR} 
	echo "backup web_`date +%Y-%m-%d` ok"  >> $LogFile
fi

#开始备份数据库目录，备份过程同上 
if [ -f ${BACKUP_DIR}/${DATABASE_PREFIX}${DATE}.tar.gz ]; then 
    echo "`date +%Y-%m-%d`'s database backup file is existing " >> $LogFile
else 
    tar -czvf ${BACKUP_DIR}/${DATABASE_PREFIX}${DATE}.tar.gz ${SYSTEM_DIR}/${DATABASE_DIR} 
	echo "backup database_`date +%Y-%m-%d` ok"  >> $LogFile
fi

#删大于3天的文件
OldWebFile="${BACKUP_DIR}/${WEBSITE_PREFIX}"$(date --date="3 days ago" +"%Y%m%d").tar.gz

if [ -f $OldWebFile ]
then
	rm -f $OldWebFile > /dev/null
	echo "Delete old web [$OldWebFile],Success!" >> $LogFile 
fi

OldDbFile="${BACKUP_DIR}/${DATABASE_PREFIX}"$(date --date="3 days ago" +"%Y%m%d").tar.gz
if [ -f $OldDbFile ]
then
	rm -f $OldDbFile > /dev/null	
	echo "Delete old db [$OldDbFile],   Success!" >> $LogFile 
fi


echo "backup `date +%Y%m%d` end"  >> $LogFile
