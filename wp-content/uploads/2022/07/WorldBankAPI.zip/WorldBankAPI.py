
import json
import  requests
import time
import sys
import os
import datetime

##@resource_reference{"WorldBankAPI.py"}
sys.path.append(os.path.dirname(os.path.abspath('WorldBankAPI.py'))) #引入资源至工作空间。

import WorldBankAPI


class WorldBank:

    def __init__(self):
        pass 

    
    def get_contries(self):
        url ='https://api.worldbank.org/v2/country?per_page=1000?format=json'
        
        res = requests.get(url)

        print(res.text)

        pass
    
    def get_topics(self):
        
        '''
        list all topics:
        
        '''
        url='http://api.worldbank.org/v2/topic?format=json'

        res = requests.get(url)
        #topics = json.loads(res.text)
        topics = [
            {'name': 'Economic', 'id': 3},
            {'name': 'Social', 'id': 15},
            {'name': 'Environment', 'id': 6},
            {'name': 'Economic', 'id': 3}

            
        ]
        if topics is not None :
            topics = topics[1]  
            for topic in topics:
                topic['sourceNote']=''

        
        print(topics)
        
        return topics


        pass 
    def get_indicators_by_topic(self, topic):
        '''
        To list all indicators under a specified topic:

        '''
        url = 'http://api.worldbank.org/v2/indicator?topic='+str(topic)

        indicators = []
        res = requests.get(url)


        pass 

    def get_indicators(self, contry, indicator, start_year, end_year):

        contry = 'chn'
        #https://api.worldbank.org/v2/country/chn?format=json
        url='https://api.worldbank.org/v2/country/'+contry+'?format=json'
        # http://api.worldbank.org/v2/sdmx/rest/data/WDI/A.NY_GDP_PCAP_PP_CD.CHN/?startperiod=2000&endPeriod=2016
        
        res = requests.get(url)

        print(res.text)

        pass

    

if __name__  == '__main__':

    print('========================== start worldbank =====================')
    #topic-> indicator

    #o = WorldBank()
    #o.get_contries()
    print(os.getcwd())

    countries = ['CHN', 'USA']
    indicators = {'NY.GDP.PCAP.PP.CD' : 'GDP per capita, PPP (current international $)'}
    dt = (datetime.datetime(2020, 1, 1), datetime.datetime(2022, 1, 1))
    #df = WorldBankAPI.get_dataframe(indicators, country=countries, convert_date=False, data_date=dt)
    df = WorldBankAPI.get_dataframe(indicators, convert_date=False, data_date=dt)

    print(df)

    

    print('==========================  end ============================')