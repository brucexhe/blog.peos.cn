﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Consul.Demo.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IApplicationLifetime appLifeTime)
        {

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseMvc();



            ////注册Consul 
            //string ip = Configuration["ip"] ?? "127.0.0.1";
            //string port = Configuration["port"] ?? "5000";
            //string serviceName = "MsgService";
            //string serviceId = serviceName + "-" + ip + "-" + port;
            //using (var consulClient = new ConsulClient(ConsulConfig))
            //{
            //    AgentServiceRegistration asr = new AgentServiceRegistration
            //    {
            //        Address = ip,
            //        Port = Convert.ToInt32(port),
            //        ID = serviceId,
            //        Name = serviceName,
            //        Check = new AgentServiceCheck
            //        {
            //            DeregisterCriticalServiceAfter = TimeSpan.FromSeconds(5),
            //            HTTP = $"http://{ip}:{port}/api/Health",
            //            Interval = TimeSpan.FromSeconds(10),
            //            Timeout = TimeSpan.FromSeconds(5),
            //        },
            //    };
            //    // 首先移除服务，避免重复注册
            //    //consulClient.Agent.ServiceDeregister(serviceId);

            //    Console.WriteLine("应用启动，注册consul");
            //    consulClient.Agent.ServiceRegister(asr).Wait();
            //}

            ////注销Consul 
            //appLifeTime.ApplicationStopped.Register(() =>
            //{
            //    using (var consulClient = new ConsulClient(ConsulConfig))
            //    {
            //        Console.WriteLine("应用退出，开始从consul注销");
            //        consulClient.Agent.ServiceDeregister(serviceId).Wait();
            //    }
            //});

            string ip = Configuration["ip"] ?? "127.0.0.1";
            string port = Configuration["port"] ?? "5000";
            string serviceName = "MsgService";
            ServiceEntity serviceEntity = new ServiceEntity
            {
                IP = ip,
                Port = Convert.ToInt32(port),
                ServiceName = serviceName,
                ConsulIP = "localhost",
                ConsulPort = "8500"
            };
            app.RegisterConsul(appLifeTime, serviceEntity);

        }



        //Consul 配置委托
        private void ConsulConfig(ConsulClientConfiguration config)
        {
            config.Address = new Uri("http://127.0.0.1:8500"); //Demo硬编码Consul的地址
            config.Datacenter = "dc1";
        }
    }
}
